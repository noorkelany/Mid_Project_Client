package data;
public enum SystemStatus {
    PARKING_SPOT_AVAILABLE,
    NO_PARKING_SPOT,
    CAR_EXISTS,
    CAR_NOT_FOUND,
    SUCCESS_DELIVERY,
    ALREADY_DELIVERED
}
